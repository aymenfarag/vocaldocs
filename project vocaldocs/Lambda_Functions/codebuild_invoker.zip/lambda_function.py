import json
import boto3
import os
import time
from botocore.exceptions import ClientError

# Initialize clients
codebuild_client = boto3.client('codebuild')

def lambda_handler(event, context):
    """
    Lambda function to trigger and monitor a CodeBuild project build.
    This replaces the local-exec provisioner in Terraform to make the build process
    platform-independent.
    
    Arguments:
        event: AWS Lambda event object containing the project name
        context: AWS Lambda context
        
    Returns:
        Dictionary with build status and details
    """
    
    # Get the CodeBuild project name from the event or environment variables
    project_name = event.get('project_name') or os.environ.get('PROJECT_NAME')
    
    if not project_name:
        return {
            'statusCode': 400,
            'body': 'Missing required parameter: project_name'
        }
    
    # Start the build
    try:
        response = codebuild_client.start_build(
            projectName=project_name
        )
        build_id = response['build']['id']
        print(f"Started build with ID: {build_id}")
    except ClientError as e:
        print(f"Error starting build: {e}")
        return {
            'statusCode': 500,
            'body': f"Failed to start build: {str(e)}"
        }
    
    # Maximum number of attempts for retrying
    max_attempts = 3
    attempt = 1
    success = False
    
    # Retry loop
    while attempt <= max_attempts:
        print(f"Build attempt {attempt} of {max_attempts}...")
        
        # Monitor the build progress
        build_successful = monitor_build(build_id)
        
        if build_successful:
            print(f"Build completed successfully on attempt {attempt}!")
            success = True
            break
        else:
            print(f"Build failed on attempt {attempt}")
            
            # If we haven't reached max attempts yet, try again
            if attempt < max_attempts:
                print(f"Waiting 30 seconds before next build attempt...")
                time.sleep(30)
                
                # Start another build
                try:
                    response = codebuild_client.start_build(
                        projectName=project_name
                    )
                    build_id = response['build']['id']
                    print(f"Started new build with ID: {build_id}")
                except ClientError as e:
                    print(f"Error starting build: {e}")
                    # Continue with next attempt even if this fails
            
        attempt += 1
    
    if not success:
        print(f"Failed to complete build successfully after {max_attempts} attempts")
        return {
            'statusCode': 500,
            'body': f"Failed to complete build successfully after {max_attempts} attempts"
        }
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'buildId': build_id,
            'status': 'SUCCESS',
            'message': f"Build completed successfully on attempt {attempt}"
        })
    }

def monitor_build(build_id):
    """
    Monitor the status of a CodeBuild project build
    
    Arguments:
        build_id: The ID of the build to monitor
        
    Returns:
        Boolean indicating if the build was successful
    """
    while True:
        # Wait 10 seconds between checks
        time.sleep(10)
        
        # Get the build status
        try:
            response = codebuild_client.batch_get_builds(ids=[build_id])
            build = response['builds'][0]
            status = build['buildStatus']
            
            print(f"Current build status: {status}")
            
            # If the build is complete, return the result
            if status != 'IN_PROGRESS':
                return status == 'SUCCEEDED'
                
        except ClientError as e:
            print(f"Error checking build status: {e}")
            return False
