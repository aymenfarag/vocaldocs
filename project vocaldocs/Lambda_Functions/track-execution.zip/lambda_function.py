import os
import json
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timezone
from botocore.config import Config 
import time

ssm = boto3.client('ssm')

def get_parameter(name):
    response = ssm.get_parameter(Name=name, WithDecryption=True)
    return response['Parameter']['Value']

# Get the random suffix from environment variables
random_suffix = os.environ.get('RANDOM_SUFFIX')

DYNAMODB_TABLE = get_parameter(f'/vocaldocs/dynamodbtablename-{random_suffix}')
S3_BUCKET = get_parameter(f'/vocaldocs/s3projectandmediabucket-{random_suffix}')
REGION = get_parameter(f'/vocaldocs/regionname-{random_suffix}')

def lambda_handler(event, context):
    print("Received event:", json.dumps(event, indent=2))
    print(f"Lambda execution started at: {datetime.now(timezone.utc).isoformat()}")
    
    if 'username' in event:
        print("username")
        return get_user_requests(event['username'])
    elif 'action' in event and event['action'] == 'generate_url' and 'reference_key' in event:
        print("PresignedURL")
        return generate_presigned_url(event['reference_key'])
    else:
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid request')
        }

def get_user_requests(username):
    print("username:", username)

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(DYNAMODB_TABLE)
    
    try:
        response = table.scan(
            FilterExpression=boto3.dynamodb.conditions.Attr('Username').eq(username)
        )
        
        items = response.get('Items', [])
        
        requests = []
        
        for item in items:
            request = {
                'reference_key': item['reference_key'],
                'fileName': item.get('FileName', 'Unknown file'),
                'TaskStatus': 'Voice-is-Ready' if item.get('TaskStatus') == 'Voice-is-Ready' else 'Work-In-Progress'
            }
            requests.append(request)
            print(request)
        return {
            'statusCode': 200,
            'body': json.dumps({
                'requests': requests
            })
        }
    
    except ClientError as e:
        print(f"An error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'An error occurred: {str(e)}')
        }


def generate_presigned_url(reference_key):
    s3_client = boto3.client('s3',region_name=REGION,config=Config(signature_version='s3v4'),endpoint_url=f'https://s3.{REGION}.amazonaws.com')
    #s3_client = boto3.client('s3', region_name= REGION)
    bucket_name = S3_BUCKET
    print(REGION)
    object_key = f'download/{reference_key}/Audio.mp3'
    
    current_time = int(time.time())
    print(f"Current UTC timestamp: {current_time}")
    print(f"Current UTC time: {datetime.now(timezone.utc).isoformat()}")

    try:
        presigned_url = s3_client.generate_presigned_url(
            'get_object',
            Params={
                'Bucket': bucket_name,
                'Key': object_key
            },
            ExpiresIn=3600,  # URL expires in 1 hour
            HttpMethod='GET'
        )
        print(f"Presigned URL generated at: {datetime.now(timezone.utc).isoformat()}")
        print(f"Presigned URL: {presigned_url}")

        return {
            'statusCode': 200,
            'headers': {
                'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
                'Pragma': 'no-cache',
                'Expires': '0'
            },
            'body': json.dumps({
                'presigned_url': presigned_url,
                'generated_at': current_time
            })
        }
    except ClientError as e:
        print(f"Error generating presigned URL for {reference_key}: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error generating URL: {str(e)}')
        }