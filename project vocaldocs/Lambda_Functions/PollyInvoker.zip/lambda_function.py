import os
import json
import boto3
import time
from botocore.exceptions import ClientError

s3 = boto3.client('s3')
polly = boto3.client('polly')
dynamodb = boto3.resource('dynamodb')
ssm = boto3.client('ssm')

# Function to get parameter from SSM Parameter Store
def get_parameter(name):
    response = ssm.get_parameter(Name=name, WithDecryption=True)
    return response['Parameter']['Value']

# Get the random suffix from environment variables
random_suffix = os.environ.get('RANDOM_SUFFIX')

DYNAMODB_TABLE = get_parameter(f'/vocaldocs/dynamodbtablename-{random_suffix}')

MAX_CHARS = 190000  # Safe limit below 200,000 characters


def lambda_handler(event, context):
    print("Received event:", json.dumps(event, indent=2))

    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    print(f"Processing file: s3://{bucket}/{key}")

    try:
        reference_key = key.split('/')[1]

        # Get language from DynamoDB
        language = get_language_from_dynamodb(reference_key)

        response = s3.get_object(Bucket=bucket, Key=key)
        text_content = response['Body'].read().decode('utf-8')

        # Split text into chunks if necessary
        text_chunks = split_text(text_content)

        audio_files = []
        for i, chunk in enumerate(text_chunks):
            task_id = start_polly_task(bucket, reference_key, chunk, i, language)
            audio_file = wait_for_polly_task(task_id)
            audio_files.append(audio_file)

        if len(audio_files) > 1:
            # Combine audio files if there are multiple chunks
            combined_audio_key = combine_audio_files(bucket, reference_key, audio_files)
            final_audio_key = rename_to_audio_mp3(bucket, combined_audio_key, reference_key)
            print(f"Combined audio file saved and renamed: s3://{bucket}/{final_audio_key}")
        else:
            final_audio_key = rename_to_audio_mp3(bucket, f"download/{reference_key}/{audio_files[0]}", reference_key)
            print(f"Single audio file renamed: s3://{bucket}/{final_audio_key}")

        update_dynamodb_status(reference_key, 'Voice-is-Ready')

        return {
            'statusCode': 200,
            'body': json.dumps('Processing completed successfully')
        }

    except Exception as e:
        print(f"Error processing file {key}: {str(e)}")
        update_dynamodb_status(reference_key, 'failed')
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error processing file: {str(e)}')
        }


def get_language_from_dynamodb(reference_key):
    table = dynamodb.Table(DYNAMODB_TABLE)
    try:
        response = table.get_item(Key={'reference_key': reference_key})
        language = response['Item']['Language'].lower()
        return language
    except ClientError as e:
        print(f"Error retrieving language from DynamoDB: {str(e)}")
        raise

def split_text(text):
    words = text.split()
    chunks = []
    current_chunk = []

    for word in words:
        if len(' '.join(current_chunk + [word])) <= MAX_CHARS:
            current_chunk.append(word)
        else:
            chunks.append(' '.join(current_chunk))
            current_chunk = [word]

    if current_chunk:
        chunks.append(' '.join(current_chunk))

    return chunks


def start_polly_task(bucket, reference_key, text, chunk_index, language):
    voice_id = get_voice_id(language)
    response = polly.start_speech_synthesis_task(
        OutputFormat='mp3',
        OutputS3BucketName=bucket,
        OutputS3KeyPrefix=f"download/{reference_key}/chunk_{chunk_index}_",
        Text=text,
        VoiceId=voice_id,
        LanguageCode=get_language_code(language)
    )
    return response['SynthesisTask']['TaskId']

def get_voice_id(language):
    if language == 'english':
        return 'Joanna'
    elif language == 'arabic':
        return 'Zeina'
    else:
        raise ValueError(f"Unsupported language: {language}")

def get_language_code(language):
    if language == 'english':
        return 'en-US'
    elif language == 'arabic':
        return 'arb'
    else:
        raise ValueError(f"Unsupported language: {language}")
    


def wait_for_polly_task(task_id):
    timeout = 300  # 5 minutes timeout
    start_time = time.time()
    while True:
        task_status = polly.get_speech_synthesis_task(TaskId=task_id)
        status = task_status['SynthesisTask']['TaskStatus']

        if status == 'completed':
            print(f"Speech synthesis task completed: {task_id}")
            return task_status['SynthesisTask']['OutputUri'].split('/')[-1]
        elif status == 'failed':
            raise Exception(f"Speech synthesis task failed: {task_id}")
        elif time.time() - start_time > timeout:
            raise Exception(f"Speech synthesis task timed out: {task_id}")

        time.sleep(5)  # Wait for 5 seconds before checking again


def rename_to_audio_mp3(bucket, source_key, reference_key):
    destination_key = f"download/{reference_key}/Audio.mp3"
    s3.copy_object(Bucket=bucket, CopySource={'Bucket': bucket, 'Key': source_key}, Key=destination_key)
    s3.delete_object(Bucket=bucket, Key=source_key)
    return destination_key


def combine_audio_files(bucket, reference_key, audio_files):
    combined_key = f"download/{reference_key}/combined_audio_info.txt"
    content = "\n".join(audio_files)
    s3.put_object(Bucket=bucket, Key=combined_key, Body=content)
    return combined_key


def update_dynamodb_status(reference_key, status):
    table = dynamodb.Table(DYNAMODB_TABLE)
    try:
        response = table.update_item(
            Key={'reference_key': reference_key},
            UpdateExpression="SET TaskStatus = :status",
            ExpressionAttributeValues={':status': status}
        )
        print(f"DynamoDB update response: {json.dumps(response, default=str)}")
    except ClientError as e:
        print(f"Error updating DynamoDB: {str(e)}")