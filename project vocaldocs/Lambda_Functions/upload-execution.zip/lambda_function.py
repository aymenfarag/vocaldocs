import os
import json
import boto3
import base64
import uuid
from datetime import datetime, timedelta
import time

ssm = boto3.client('ssm')

# Function to get parameter from SSM Parameter Store
def get_parameter(name):
    response = ssm.get_parameter(Name=name, WithDecryption=True)
    return response['Parameter']['Value']

# Get the random suffix from environment variables
random_suffix = os.environ.get('RANDOM_SUFFIX')    

DYNAMODB_TABLE = get_parameter(f'/vocaldocs/dynamodbtablename-{random_suffix}')
S3_BUCKET = get_parameter(f'/vocaldocs/s3projectandmediabucket-{random_suffix}')

def lambda_handler(event, context):
    print("Received event:", json.dumps(event, indent=2))
    print("Reached 0")
    
    try:
        # Extract information from the event
        file_name = event['fileName']
        language = event['language']
        start_page = event['startPage']
        end_page = event['endPage']
        file_content_base64 = event['fileContent']
        username = event['username']  # This will now be the user's email
        
        # Decode the file content from base64
        file_content = base64.b64decode(file_content_base64)
        
        # Generate a unique ID for the request
        reference_key = str(uuid.uuid4())
        print("reference_key", reference_key)
        print("Reached 1")

        # Upload file to S3
        s3_client = boto3.client('s3')
        bucket_name = S3_BUCKET
        s3_path = f"upload/{reference_key}/{file_name}"
        
        s3_client.put_object(
            Bucket=bucket_name,
            Key=s3_path,
            Body=file_content
        )
        
        print(f"Uploaded file to S3 at path: s3://{bucket_name}/{s3_path}")
        # Get current date and time
        current_datetime = datetime.utcnow()
        current_datetime_iso = current_datetime.isoformat()
        print(f"Current datetime: {current_datetime_iso}")
        print("Reached 2")

        # Calculate expiration time (1 week from now)
        expiration_time = current_datetime + timedelta(weeks=1)
        expiration_timestamp = int(expiration_time.timestamp())  # Convert to Unix timestamp

        # Save details to DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(DYNAMODB_TABLE)
        
        item = {
            'reference_key': reference_key,
            'FileName': file_name,
            'Language': language,
            'StartPage': start_page,
            'EndPage': end_page,
            'S3Path': f"s3://{bucket_name}/{s3_path}",
            'UploadDateTime': current_datetime_iso,
            'TaskStatus': 'Upload-Completed',
            'Username': username,  # This will be the user's email
            'ExpiresAt': expiration_timestamp  # Add the TTL field
        }
        
        table.put_item(Item=item)
        
        print("Reached 3")

        # Return success response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Your document has been submitted, it may take up to 5 minutes to complete the Job.',
                'reference_key': reference_key
            })
        }
    
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'An error occurred: {str(e)}')
        }